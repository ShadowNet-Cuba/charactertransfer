local myJSON = json.json
json = {}

CHDMP = CHDMP or {}
local private = {}
private.dmp = {};

-- Initialize variables
local totalTimePlayed = 0
local timePlayedThisLevel = 0
local playerInfoReady = false

local frame = CreateFrame("Frame")
frame:RegisterEvent("TIME_PLAYED_MSG")

frame:SetScript("OnEvent", function(self, event, total, thisLevel)
  totalTimePlayed = total
  timePlayedThisLevel = thisLevel

  -- Now that we have the playtime, set the flag to true
  playerInfoReady = true
end)

-- Send the request
RequestTimePlayed()

function GetPlayTime()
  if playerInfoReady then
    return totalTimePlayed
  else
    return nil
  end
end

function private.GetGlobalInfo()
    local retTbl            = {}
    retTbl.locale           = GetLocale();
    retTbl.realm            = GetRealmName();
    retTbl.realmlist        = GetCVar("realmList");
    local version, build, date, tocversion = GetBuildInfo();
    retTbl.clientbuild      = build;
    return retTbl;
end

function private.GetPlayerStats()
  local stats = {}


  stats.health = UnitHealthMax("player")

  local base, _, _, _ = UnitStat("player", 1) -- Strength
  stats.strength = base

  base, _, _, _ = UnitStat("player", 2) -- Agility
  stats.agility = base

  base, _, _, _ = UnitStat("player", 3) -- Stamina
  stats.stamina = base

  base, _, _, _ = UnitStat("player", 4) -- Intellect
  stats.intellect = base

  base, _, _, _ = UnitStat("player", 5) -- Spirit
  stats.spirit = base

  return stats
end


function private.GetUnitInfo()
    local retTbl            = {}
    retTbl.name             = UnitName("player");
    local _, class          = UnitClass("player");
    retTbl.class            = class;
    retTbl.level            = UnitLevel("player");
    local _,race            = UnitRace("player");
    retTbl.race             = race;
    retTbl.gender           = UnitSex("player");
    local honorableKills    = GetPVPLifetimeStats()
    retTbl.kills            = honorableKills;
    retTbl.honor            = GetHonorCurrency();
    retTbl.arenapoints      = GetArenaCurrency();
    retTbl.money            = GetMoney();
    retTbl.specs            = GetNumTalentGroups();
    retTbl.playtime        = GetPlayTime();
    
    return retTbl;
end
function private.GetSpellData()
    local retTbl = {}
    for i = 1, MAX_SKILLLINE_TABS do
        local name, _, _, offset, numSpells = GetSpellTabInfo(i);
        if not name then
            break;
        end
        for s = offset + 1, offset + numSpells do
            local spellInfo = GetSpellLink(s, BOOKTYPE_SPELL);
            if spellInfo ~= nil then
                for spellid in string.gmatch(GetSpellLink(s, BOOKTYPE_SPELL),".-Hspell:(%d+).*") do 
                    retTbl[spellid] = i;
                end 
            end
        end
    end
    private.ILog("Spells DONE..."); 
    return retTbl;
end

function private.GetCurrencyData()
    local retTbl = {}
    for i = 1, GetCurrencyListSize() do
        local name, _, _, _, _, count, _, _, itemID = GetCurrencyListInfo(i)
        retTbl[i] = {['C'] = count, ['I'] = itemID};
    end 
    return retTbl;
end
function private.GetMACData()
    local retTbl = {}
    for i = 1, GetNumCompanions("MOUNT") do
        local _, _, M = GetCompanionInfo("MOUNT", i);
        retTbl["M:"..i] = M;
    end
    for i = 1, GetNumCompanions("CRITTER") do
        local _, _, C = GetCompanionInfo("CRITTER", i);
        retTbl["C:"..i] = C;
    end    
    private.ILog("Mounts & Critters DONE...");    
    return retTbl;
end

function private.GetAchievementCategoryData()
  private.ILog("GetAchievementCategoryData called")  -- Debugging print statement


  local achievements = {}



  local numAchievements = GetCategoryNumAchievements(-1)
  for index = 1, numAchievements do
    local achievementID, _, points, completed, month, day, year, _, _, _, _, isGuildAch, _, _, _ = GetAchievementInfo(-1, index)
    local categoryID = GetAchievementCategory(achievementID)
    local achievement = {
      id = achievementID,
      points = points,
      completed = completed and 1 or 0,
      time = completed and time({ year = 2000 + year, month = month, day = day }) or 0,
      isGuildAchievement = isGuildAch,
      category = categoryID,
      
    }
    table.insert(achievements, achievement)

  end

 
 

  return achievements
end

function SendQueryQuestsCompleted()
  private.ILog("SendQueryQuestsCompleted called")  -- Debugging print statement

  local completedQuests = {}
  
  C_QuestLog.QueryQuestsCompleted()

  -- Wait for the QUEST_QUERY_COMPLETE event to receive the result
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("QUEST_QUERY_COMPLETE")
  frame:SetScript("OnEvent", function(self, event, ...)
    if event == "QUEST_QUERY_COMPLETE" then
      for index = 1, GetNumQuestLogEntries() do
        local questID = tonumber(GetQuestLogQuestID(index))
        if questID then
          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(questID)
          completedQuests[questID] = isCompleted
        end
      end

      -- Process the completedQuests table here or store it as needed
      -- ...

      -- Unregister the event and clear the frame
      self:UnregisterAllEvents()
      self:SetScript("OnEvent", nil)
    end
  end)
end














-- Main function to gather all the required data
function GetAllAchievementData()
  local totalPoints = GetTotalAchievementPoints()
  local totalAchievements, completedAchievements = GetNumCompletedAchievements()

  local data = {
    Main = {
      totalPoints = totalPoints,
      totalAchievements = totalAchievements,
      completedAchievements = completedAchievements
    },
    
  }

  return data
end








function private.GetRepData()
    local retTbl = {}
    for i = 1, GetNumFactions() do 
        local name, _, _, _, _, earnedValue, _, canToggleAtWar, _, _, _, _, _ = GetFactionInfo(i)
        retTbl[i] = {["N"] = name, ["V"] = earnedValue, ["F"] = bit.bor(((not canToggleAtWar) and 16) or 0)} 
    end
    private.ILog("Reputations DONE...");
    return retTbl;
end

function private.GetIData()
    local retTbl = {}
    for i = 0, 135 do 
        local itemLink = GetInventoryItemLink("player", i) 
        if itemLink then 
            local equipSlot = select(9, GetItemInfo(itemLink))
            local quality = select(3, GetItemInfo(itemLink))
            local count = equipSlot == "INVTYPE_BAG" and 1 or GetInventoryItemCount("player", i)
            local itemId, enchantId = itemLink:match("item:(%d+):(%d+)")
            
            
local gem1name, gem1Link = GetItemGem(itemLink, 1)
local gem2name, gem2Link = GetItemGem(itemLink, 2)
local gem3name, gem3Link = GetItemGem(itemLink, 3)
if gem1name then
  G1 = gem1Link:match("item:(%d+)")
else 
  G1 = 0
end

if gem2name then
  G2 = gem2Link:match("item:(%d+)")
else 
  G2 = 0
end

if gem3name then
  G3 = gem3Link:match("item:(%d+)")
else 
  G3 = 0
end

            retTbl["0000:"..i] = {["I"] = itemId, ["C"] = count, ["E"] = enchantId, ["G1"] = G1, ["G2"] = G2, ["G3"] = G3, ["Quality"] = quality}
        end 
    end
    for bag = 0, 11 do 
        for slot = 1, GetContainerNumSlots(bag) do 
            local itemLink = GetContainerItemLink(bag, slot) 
            if itemLink then 
                local count = select(2, GetContainerItemInfo(bag, slot))
                local p = bag + 1000;
                local quality = select(3, GetItemInfo(itemLink))

                local itemId, enchantId = itemLink:match("item:(%d+):(%d+)")
             
local gem1name, gem1Link = GetItemGem(itemLink, 1)
local gem2name, gem2Link = GetItemGem(itemLink, 2)
local gem3name, gem3Link = GetItemGem(itemLink, 3)
if gem1name then
  G1 = gem1Link:match("item:(%d+)")
else 
  G1 = 0
end

if gem2name then
  G2 = gem2Link:match("item:(%d+)")
else 
  G2 = 0
end

if gem3name then
  G3 = gem3Link:match("item:(%d+)")
else 
  G3 = 0
end


                retTbl[p..":"..slot] = {["I"] = itemId, ["C"] = count,["E"] = enchantId, ["G1"] = G1, ["G2"] = G2, ["G3"] = G3, ["Quality"] = quality}
            end 
        end 
    end
    private.ILog("Inventory DONE...");    
    return retTbl;
end



local professionSpellIds = {
    [2259] = GetSpellInfo(2259), -- Alchemy
    [2018] = GetSpellInfo(2018), -- Blacksmithing
    [7411] = GetSpellInfo(7411), -- Enchanting
    [4036] = GetSpellInfo(4036), -- Engineering
    [2366] = GetSpellInfo(2366), -- Herb Gathering
    [45357] = GetSpellInfo(45357), -- Inscription
    [25229] = GetSpellInfo(25229), -- Jewelcrafting
    [2108] = GetSpellInfo(2108), -- Leatherworking
    [8613] = GetSpellInfo(8613), -- Skinning
    [3908] = GetSpellInfo(3908), -- Tailoring
    [45542] = GetSpellInfo(45542), -- First Aid
    [65293] = GetSpellInfo(65293), -- Fishing
    [51296] = GetSpellInfo(51296), -- Cooking
    [762] = GetSpellInfo(762), -- Riding
    [356] = "Angeln", -- Angeln
    
    
    -- Add any other professions here
}

function private.GetSkillData()
    local retTbl = {}
    local WeaponSKillNames = GetWeaponSKillNames()

    for i = 1, GetNumSkillLines() do 
        local skillName, isHeader, _, skillRank, _, _, skillMaxRank, _, _, _, _, _, _ = GetSkillLineInfo(i)
        if not isHeader then
            retTbl[i] = {
                ["N"] = skillName,
                ["C"] = skillRank,
                ["M"] = skillMaxRank,
                ["S"] = nil,
                ["P"] = nil
            }

            for _, achievement in pairs(WeaponSKillNames) do
                if skillName == achievement.criteriaString then
                    retTbl[i]["Skill"] = achievement.assetID
                    break
                end
            end

            -- Check if skillName is in professionSpellIds
            for spellId, professionName in pairs(professionSpellIds) do
                if skillName == professionName then
                    retTbl[i]["S"] = spellId
                    break
                end
            end
        end 
    end
    return retTbl;
end


function GetWeaponSKillNames()
    local numCriteria = GetAchievementNumCriteria(705)
    local achievementData = {}

    for i = 1, numCriteria do
        local criteriaString, criteriaType, completed, quantity, requiredQuantity, characterName, flags, assetID, quantityString, criteriaID, eligible = GetAchievementCriteriaInfo(705, i)
        achievementData[i] = {
            criteriaString = criteriaString,
            criteriaType = criteriaType,
            completed = completed,
            quantity = quantity,
            requiredQuantity = requiredQuantity,
            characterName = characterName,
            flags = flags,
            assetID = assetID,
            quantityString = quantityString,
            criteriaID = criteriaID,
            eligible = eligible
        }
    end

    return achievementData
end


function private.GetTalentTree()
    local talentData = {}
    for i = 1, GetNumTalentGroups() do
        talentData[i] = {}
        for tab = 1, GetNumTalentTabs() do
            local tabName, tabTexture, _, _, _, _ = GetTalentTabInfo(tab, false, false, i)
            talentData[i][tab] = {
                name = tabName,
                icon = tabTexture and tabTexture:match("Interface\\Icons\\(.+)"),
                talents = {}
            }
            for talent = 1, GetNumTalents(tab) do
                local name, icon, _, _, currentRank, maxRank = GetTalentInfo(tab, talent, false, false, i)
                
                local talentLink = GetTalentLink(tab, talent)
                local talentID = talentLink and tonumber(talentLink:match("talent:(%d+)"))
                
                talentData[i][tab].talents[talent] = {
                    name = name,
                    icon = icon and icon:match("Interface\\Icons\\(.+)"),
                    currentRank = currentRank,
                    maxRank = maxRank,
                    tab = tab,
                    talent = talent,
                    talentID = talentID
                }
            end
        end
    end
    return talentData
end







function private.DumpPlayerStats()
    local playerStats = {}
    -- Get the number of player stats available
    local numPlayerStats = GetNumStats()

    -- Iterate through each stat and save it in our table
    for i = 1, numPlayerStats do
        -- Fetch the stat name and value
        local stat, value = GetStatInfo(i)

        -- Save the stat in our table
        playerStats[stat] = value
    end

    -- Return our table of player stats
    return playerStats
end



function private.GetGlyphData()
    local retTbl = {}
    for i = 1, GetNumTalentGroups() do
        retTbl[i] = {}
        for j = 1, 6 do
            local Link = GetGlyphLink(j, i)
            if Link then
               local _, glyphID = Link:match("Hglyph:(%d+):(%d+)")
                if glyphID then
                    retTbl[i][j] = tonumber(glyphID)
                 else
                    retTbl[i][j] = 0
                end
            end
        end
    end
    private.ILog("Glyphs DONE...")
    return retTbl
end





function private.DumpPlayerStatistic()
    local playerStatistics = {}

    -- Get the list of statistic categories
    local categoryList = GetStatisticsCategoryList()

    -- Iterate through each category
    for _, categoryId in pairs(categoryList) do
        local categoryName = GetCategoryInfo(categoryId)
        local numStats = GetCategoryNumAchievements(categoryId)

        -- Iterate through each statistic in the category
        for i = 1, numStats do
            local id, name = GetAchievementInfo(categoryId, i)
            local ok, quantity = pcall(GetStatistic, id)
            if ok then
                local statistic = {
                    id = id,
                    name = name,
                    quantity = quantity,
                    criteria = {}
                }

                local numCriteria = GetAchievementNumCriteria(id)
                for j = 1, numCriteria do
                    local criteriaString, criteriaType, completed, quantity, reqQuantity, charName, flags, assetID, quantityString, criteriaID, eligible, duration, elapsed = GetAchievementCriteriaInfo(id, j)
                    local criterion = {
                        criteriaString = criteriaString,
                        criteriaType = criteriaType,
                        completed = completed,
                        quantity = quantity,
                        reqQuantity = reqQuantity,
                        charName = charName,
                        flags = flags,
                        assetID = assetID,
                        quantityString = quantityString,
                        criteriaID = criteriaID,
                        eligible = eligible,
                        duration = duration,
                        elapsed = elapsed
                    }
                    table.insert(statistic.criteria, criterion)
                end

                table.insert(playerStatistics, statistic)
            end
        end
    end

    return playerStatistics
end




function private.ExtractMacros()
    local macroCount = GetNumMacros()
    local macros = {}
    
    for i = 1, macroCount do
        local macroName, _, macroBody = GetMacroInfo(i)
        macros[i] = {
            name = macroName,
            body = macroBody
        }
    end
    
    local macrosObj = { macros = macros }
    
    return macrosObj
end




function private.CreateCharDump()

  private.dmp.unitstats        = private.trycall(private.GetPlayerStats, private.ErrLog)    or {private.ErrLog};
  private.dmp.globalinfo        = private.trycall(private.GetGlobalInfo, private.ErrLog)    or {private.ErrLog};
  private.dmp.unitinfo        = private.trycall(private.GetUnitInfo, private.ErrLog)      or {private.ErrLog};
 -- private.dmp.makros         = private.trycall(private.ExtractMacros, private.ErrLog)       or {private.ErrLog}; -- Parsing error in json later, not fixxed yet
  private.dmp.reputation         = private.trycall(private.GetRepData, private.ErrLog)       or {private.ErrLog};
  private.dmp.skillnames  = private.trycall(GetWeaponSKillNames, private.ErrLog)  or {private.ErrLog};
  private.dmp.achiev      = private.trycall(private.GetAchievementCategoryData, private.ErrLog)  or {private.ErrLog};
  private.dmp.glyphs      = private.trycall(private.GetGlyphData, private.ErrLog)     or {private.ErrLog};
  private.dmp.creature    = private.trycall(private.GetMACData, private.ErrLog)       or {private.ErrLog};
  private.dmp.spells      = private.trycall(private.GetSpellData, private.ErrLog)     or {private.ErrLog};
  private.dmp.talents     = private.trycall(private.GetTalentTree, private.ErrLog)     or {private.ErrLog};
  private.dmp.skills      = private.trycall(private.GetSkillData, private.ErrLog)     or {private.ErrLog};
  private.dmp.inventory   = private.trycall(private.GetIData, private.ErrLog)         or {private.ErrLog};
  --private.dmp.statistic   = private.trycall(private.DumpPlayerStatistic, private.ErrLog)         or {private.ErrLog};  -- too much, needs to be filtered some not includes like halion kills. Killcounts animals undead etc are just serverside, need to fix that
  private.dmp.currency    = private.trycall(private.GetCurrencyData, private.ErrLog)  or {private.ErrLog};
    return b64_enc(myJSON.encode(private.dmp));
end
function private.Log(str_in)
    print("\124c0080C0FF  "..str_in.."\124r");
end
function private.ErrLog(err_in)
    private.errlog = private.errlog or ""
    private.errlog = private.errlog .. "err=" .. b64_enc(err_in) .. "\n"
    print("\124c00FF0000"..(err_in or "nil").."\124r");
end
function private.GetCharDump()
    return b64_enc(private.CreateCharDump());
end
function private.ILog(str_in)
    print("\124c0080FF80"..str_in.."\124r");
end
function private.trycall(f,herr)
    local status, result = xpcall(f,herr)
    if status then 
        return result;
    end
    return status;
end
function private.SaveCharData(data, key)
    private.ILog("Chardump DONE: you can find dump here: WoW Folder \\WTF\\Account\\%Username%\\SavedVariables\\chardump.lua ");    
    CHDMP_DATA  = data
    CHDMP_KEY   = key
    CHDMP_VER   = GetAddOnMetadata("chardump", "Version")
end
function private.TradeSkillFrame_OnShow_Hook(frame, force)
    if private.done == true then
        return
    end

    if frame and frame.GetName and frame:GetName() == "TradeSkillFrame" then
		private.dmp.recipes = private.dmp.recipes or {};
		for i=1, GetNumTradeSkills() do
			local link = GetTradeSkillRecipeLink(i);
			if link then
				local spellId = tonumber(link:match("enchant:(%d+)")); 
				private.dmp.recipes[spellId] = spellId;
			end
		end

		print("Profession scanned!")


        local isLink, _ = IsTradeSkillLinked();
        if isLink == nil then
            local link = GetTradeSkillListLink();
            if link then
		        local skillname = link:match("%[(.-)%]");
		        private.dmp = private.dmp or {};
		        private.dmp.skilllink = private.dmp.skilllink or {};
				private.dmp.skilllink[skillname] = link;
				print("Chardump: TradeSkillFrame_Show",skillname,link)
            end
        end

		
    end 
end

--hooksecurefunc(_G, "ShowUIPanel", private.TradeSkillFrame_OnShow_Hook);

SLASH_CHDMP1 = "/chardump";
SlashCmdList["CHDMP"] = function(msg)
    if msg == "done" then
        private.done = true;
        return;
    elseif msg == "help" then
        return;
    else
        private.done = false;
    end
    
    
    for _, spellName in pairs(professionSpellIds) do
    CastSpellByName(spellName)
    end
    
local foo, bar, baz, qux, quux, quuz
foo = math.pi * math.sqrt(2); qux = "This is a decoy"; quux = {}; quuz = "Another decoy"
bar = (function() local useless = "This string is pointless"; return private.GetCharDump() end)()

qux = string.rep("pointless", 10); quuz = nil; quux = {}; foo = math.sin(math.pi)

baz = (function() local pointless = "Really, this is pointless"; return string.sub(bar, 1, #bar - 64) end)()
qux = string.reverse("decoy"); foo = math.cos(math.pi)

quux = (function() local decoy = "Decoy here"; return string.sub(bar, #bar - 63) end)()

quuz = "Decoy again"; foo = math.tan(math.pi)

private.SaveCharData(baz, quux)
qux = string.format("%s_%s", "decoy", "again"); quuz = {}; foo = math.acos(0)


end
